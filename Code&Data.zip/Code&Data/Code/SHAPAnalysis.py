#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec 18 16:05:02 2023

@author: a
"""

import pandas as pd
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import datetime
import xgboost
import shap
#%%Change the Columns' names
mpl.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['font.size'] = 12 
df = pd.read_excel('datatotal_dropna.xlsx')
df.rename(columns={
    'MSCI Index': 'MSCI',
    'U.S. Treasury earnings': 'U.S. Treasury',
    'Natural gas New York': 'NG',
    'LME Aluminum': 'Aluminum',
    'LME Copper': 'Copper',
    'LME Lead': 'Lead',
    'LME Tin': 'Tin'
}, inplace=True) 
df = df.drop(['交易量','交易量.1','交易量.2','交易量.3','交易量.4','交易量.5','交易量.6','交易量.7','交易量.8'],axis = 1)
df_c = df.iloc[36:,:]
data = df_c
#%% grab the independent and dependent varables 
X = data[['MSCI', 'U.S. Treasury', 'Copper', 'Nickel', 'GBP_USD', 'JPY_USD', 'Maker', 'BTC', 'VIX', 'Uncertainty index']]
y = data['Theta']
#%% train with XG Boost and apply to SHAP

params = {
    "objective": "reg:squarederror",
    "learning_rate": 0.06, 
    "max_depth": 4,
    "min_child_weight": 3,
    "subsample": 0.9,
    "colsample_bytree": 0.8,
    "gamma": 0.1,
    "reg_lambda": 2.0,
    "reg_alpha": 0.0,
}

model = xgboost.train(params, xgboost.DMatrix(X, label=y), 100)
# compute SHAP values
explainer = shap.Explainer(model, X)
shap_values = explainer(X)

#%% plot the shap result
shap.plots.beeswarm(shap_values)
shap.plots.heatmap(shap_values)
shap.plots.violin(shap_values)
shap.plots.bar(shap_values.cohorts(2).abs.mean(0)) 
shap.plots.scatter(shap_values[:, "MSCI"]) 

